package com.ttk.exception;

public class BookShelfNotFoundException extends RuntimeException {
	
	public BookShelfNotFoundException(String message)
	{
		super(message);

	}


}
