package com.ttk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TastytalesspringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(TastytalesspringbootApplication.class, args);
	}

}
